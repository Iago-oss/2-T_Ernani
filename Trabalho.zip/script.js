
const botao = document.querySelector('#enviar');

const input = document.querySelector('#problema');


//alert(input.value)


function enviarMensagem(evt) {
    evt.preventDefault();
    let mensagem = input.value;

    alert(mensagem);

    input.value = '';

    alert('Obrigado pelo Feedback!')




}

botao.addEventListener("click", enviarMensagem)