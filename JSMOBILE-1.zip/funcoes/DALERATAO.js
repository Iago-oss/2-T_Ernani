// const nome = laura
// function retornaDados() {
//     //CODIGO COM RETORNO
//     return nome.toUppercasese()
//     console.log('testando...')//INALCANÇAVEL
//     //A PARTIR DESSA LINHA NÃO EXECUTA MAIS NADA...
// }
// const dados = retornaDados()
// console.log(dados)

const nome = 'laura'
const idade = 23
const cpf = '123.456.789-00'

function dadosCompletos(nome, idade, cpf) {
    return ('seu nome é: ' + nome + ' sua idade é: ' + idade + ' anos, seu cpf é: ' + cpf)
}

dados = dadosCompletos(nome, idade, cpf)
console.log(dados)
