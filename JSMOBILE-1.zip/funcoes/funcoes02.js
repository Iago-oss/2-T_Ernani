
// function soma(n1, n2) {
//     if (typeof n1 === 'number' && typeof n2 === 'number') {
//         const res = n1 + n2;
//         alert('O resultado da soma é: ' + res)
//     } else {
//         alert('Faça o favor de Informar números validos')
//     }
// }




// soma('gala', 7)
// soma(-5, 7)
// soma(85, -57)
// soma(68, '47')

// CRIE UMA FUNÇÃO QUE RECEBA PARAMETROS 
//NOME, ALTUR
//CHUQUE SE NOME É STRING E ALTURA É NUMERO
//SE AS 2 CONDIÇÕES ACIMA FOR VERDADEIRA RETORNE 
//"OLA" + NOME + "SUA ALTURA É" + ALTURA 

// function apresentacao(nome, altura) {
//     if (typeof nome === 'string' && typeof altura === 'number') {
//           alert(" Ola " + nome + " sua altura é " + altura)

//     } else {
//         alert('informe seus dados corretamente')

//     }


// }
// apresentacao('Carlinhos', 1.98)
// apresentacao(907, true)
// apresentacao(true, 857)









