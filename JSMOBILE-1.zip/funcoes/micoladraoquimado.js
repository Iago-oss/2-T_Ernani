// function ola(nome, sobrenome) {
//     if (typeof nome === 'string' && typeof sobrenome === 'string') {
//           alert( "ola " + nome + " " + sobrenome)

//     } else {
//         alert('digite seu nome corretamnete')

//     }
// }


// ola('Carlinhos', 'Galinha')








//  function dados(nome, altura) {
//     if (typeof nome === 'string' && typeof altura === 'number') {
//           alert(" Ola " + nome + " sua altura é " + altura)

//     } else {
//        alert('informe seus dados corretamente')
//      }
//  }

//  dados('Thomas Turbando', 1.99)






// function numero(numero) {
// if(typeof numero === 'number') {
//     if (numero % 2 === 0) {
//         alert('O numero ' + numero + ' é par')
//     } else {
//         alert('O numero ' + numero + ' é impar')
//     }
// }else {
//     alert('por favor, informe um numero')
// }}
// numero(2)

// numero(3)

// numero('dalva')










































