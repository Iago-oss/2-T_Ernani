/**
FUNÇÕES:são blocos de codigo que podem ser resproveiatdos 
*Funções podem ou não ter nomes 
*Podem ou não receber parametros
*/
//CRIAR OU DECLARAR FUNÇÕES 


function dizOla(nome) {
    //CODIGO QUE SERA EXECUTADO
    console.log("Ola " + nome)


}

dizOla('Dalva')
dizOla('Carlinhos')
dizOla('Cleide')
//INVOCAR / CHAMAR FUNÇÕES

//FUNÇÃO PARA 

//ADIÇÃO
function somaDoisNumeros(num1, num2) {
    const soma = num1 + num2
    console.log(soma)
}
somaDoisNumeros(554448485, 556464545)

//SUBTRAÇÃO
function subtraiQuatroNumeros(num1, num2, num3, num4) {
    const subtracao = num1 - num2 - num3 - num4
    console.log(subtracao)
}
subtraiQuatroNumeros(948575, 5485, 5485, 5485)

//DIVISÃO
function dividirTresNumeros(num1, num2, num3) {
    const dividir = num1 / num2 / num3
    console.log(dividir)
}
dividirTresNumeros(95775, 8, 94)




//MUTIPLICAR
function mutipliarQuinzeNumeros(num1, num2, num3, num4, num5, num6, num7, num8, num9, num10, num11, num12, num13, num14, num15) {
    const mutiplicar = num1 * num2 * num3 * num4 * num5 * num6 * num7 * num8 * num9 * num10 * num11 * num12 * num13 * num14 * num15
    console.log(mutiplicar)
}
mutipliarQuinzeNumeros(955, 8, 94, 775, 8, 94, 955, 8, 94, 957, 8, 94, 955, 8, 94)














