/**
 *DECLARAÇÃO DE VARIÁVEIS JAVASCRIPT:
 * identificador;nome da variavel
 * valor:valor inicial da variavel
 */
const nome = "carlinhos ";        //espaço global - mutavel 
const sobrenome = " de cavalos ";     //espaço local - mutavel
const idade = 32;  //espaço local - imutavel


//REATRIBUINDO VALORES
//pet = "cachorro";
//nome = "tio-patinhas";
//PI = 3.14; DA ERROR(NÃO MUDA)

// CONTATENAR VALORES (JUNTAR) SÃO OS +


//const dadosPessoais = nome+sobrenome+ "IDADE:"+idade;

const ano = 2024
const anoNascimento = 1979
const idadeAtual = ano - anoNascimento

const num = 24
const ehPar = num % 2 === 0 //par
const ehImpar = num % 2 === 1 //impar

if (ehPar) {
  console.log("o numero Par")
} else {
  console.log("O numero é impar")
}




//console.log(parOUImpar)
//console.log(imparOUPar)


//IF = SE - ELSE = SENÃO imparOU



//console.log(dadosPessoais)
//console.log(idadeAtual+ " anos")



/**CRIE UMA VARIAVEL PARA CADA SITUAÇÃO  */
//passsaTempo;
//cidade;
//Preço do Dolar;
//animalEstimação;
//estaSoltario = false or true
//todos os dados (contatenar)

//const passaTempo = " jogar. ";
//const cidade = " curitiba. ";
//const precoDolar = 5.12;
//const animalEstimação = " chloe. ";
//const estaSoltario = true

//const RG = "Passa tempo:"+passaTempo+"Cidade:"+cidade+"Preço do Dolar:"+precoDolar+" "+"Animal de Estimação:"+" "+animalEstimação+ "esta Solterio:"+estaSoltario;


//console.log(passaTempo)
//console.log(cidade)
//console.log(precoDolar)
//console.log(animalEstimação)
//console.log(estaSoltario)

//console.log(RG)



















