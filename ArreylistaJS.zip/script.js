// ARREY OU LISTA DE SEQUENCIA DE VALORES
const prod1 = "Camisa"
const prod2 = "Bermuda"
const prod3 = "Calça"

const produtos = ["Camisa", "Bermuda", "Calça", "Sapato"]
//                    0        1          2        3
const precos = [10.99, 20, 30, 40.99]
//                0     1   2    3
produtos[5] //indefinido
produtos[2] // Camisa
produtos[5] = "Boné"
produtos[4] = "Copo do Carlinhos"
produtos[6] = "eu jogando de dyna 💀"
produtos[7] = "meu time vendo 🥵"

//SAIDA DE DADOS (alert, console.log, innerHTML)
console.log(produtos[0])
console.log(produtos[1])
console.log(produtos[2])
console.log(produtos[3])
console.log(produtos[4])
console.log(produtos[5])
console.log(produtos[6])
console.log(produtos[7])

console.log(precos[0])
console.log(precos[1])
console.log(precos[2])
console.log(precos[3])



