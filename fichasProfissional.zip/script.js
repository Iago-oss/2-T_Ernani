
                //*NOME*

const nome = document.getElementById('nome');

const novoNome = "Dalva"

// NOVOS VALORES ATRIBUIDOS DE FORMA DINAMICA
nome.innerHTML = novoNome;

            //*SOBRENOME*

const sobrenome = document.getElementById('sobrenome')

// VALORES VARIAVEIS
const novoSobrenome = "Bebe"

// NOVOS VALORES ATRIBUIDOS DE FORMA DINAMICA
sobrenome.innerHTML = novoSobrenome

                // CGM            

const cgm = document.getElementById('cgm')

const novocgm = "674117418"

cgm.innerHTML = novocgm

            // EMAIL

const email = document.getElementById('email')

const novoEmail = "ztejzdfkçvbaeud@onorario.com"

email.innerHTML = novoEmail

            // IDADE

const idade = document.getElementById('idade')

const novaidade = 45

idade.innerHTML = novaidade