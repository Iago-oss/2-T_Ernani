//selecionar elementos html 
const linha = document.querySelector('.linha');
const color = document.querySelector('#color');
const range = document.querySelector('#range');
const box = document.querySelector('.box');
const valorCor = document.querySelector('.valor-cor');





//criar eventos de manipulação
range.value = 0;
//input 
range.addEventListener('input', function() {
  box.style.borderRadius = range.value + 'px';
})
color.addEventListener('input', function() {
  box.style.backgroundColor = color.value;
  valorCor.innerHTML = color.value;
  valorCor.style.color = "white";
})






