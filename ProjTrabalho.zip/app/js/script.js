// // Função para baixar um arquivo
// function downloadFile() {
//     const link = document.createElement('a');
//     link.href = 'https://s2-autoesporte.glbimg.com/jVTr28cUC93n00mXwM_ASQT-tNI=/1080x608/top/smart/https://i.s3.glbimg.com/v1/AUTH_cf9d035bf26b4646b105bd958f32089d/internal_photos/bs/2024/t/6/61vh2bQfAm6yl3Zjshbg/huayra-r-evo-02-3-4-frontale.jpg'; // URL do arquivo a ser baixado
//     link.download = 'arquivo.txt'; // Nome do arquivo ao fazer o download
//     link.click();
// }






