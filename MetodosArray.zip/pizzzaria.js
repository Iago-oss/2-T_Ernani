/**
 * 1) Crie um algoritmo que faça o seguinte:
 * 
     a) pergunte o nome do cliente e armazene em uma variável
     b) cumprimente o cliente e pergunte qual pizza ele quer pedir
     c) enquanto ele não tiver feito 3 pedidos continue perguntando
     d) a cada pedido feito, adicione o sabor escolhido a um array
     e) ao final, informe ao cliente a quantidade de pizzas do pedido
     f) imprima quais pizzas foram pedidas
 */

let sabores = [] // criar arrey vazia
let pedidos = 0

const usuario = prompt("Ola, Qual seu nome?")

if (usuario) {

     // loop infinito ate atingir a condição
     while (pedidos < 3) {
          let sabor = prompt("Qual sabor de pizza você deseja?")


          if (sabor) {

               sabores.push(sabor)// ENVIAR PARA FINAL DA LISTA 
               alert("Sabor adicionado com sucesso")
               pedidos = pedidos + 1 // Acumulação 
          }
     }
     // IMPRIMIR A LISTA DE SABORES
     alert("pedido fechado, olhe seu log para saber seu pedidos")
     console.log("------------------------🍕PIZZARIA MELHOR GOSTO🍕-----------------------")
     console.log(sabores)
     console.log("------------------------------------------------------------------------")

} else {
     alert("coloque seu nome")
}





















