// METODOS DE ARRAY
const comidas = ['churrasco', 'pizza']

comidas[3] = 'geleia' //MANUAL 
comidas.push('cenoura') // EMPURRAANDO VALOR PARA O FINAK DL ARREY 
comidas.pop() // RETIRA O ULTIMO VALOR DO ARREY
comidas.shift() // RETIRA O PRIMEIRO VALOR DO ARREY
comidas.unshift('banana') // ADICIONA O VALOR NO INICIO DO ARREY
comidas[2] = 'melancia'

const tamanho = comidas.length 

console.log("exitem " + tamanho + " itens na lista") // CONTAGEM DE VALORES DO ARREY




console.log(comidas)






             