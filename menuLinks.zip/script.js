//Selecionar Com "querySlector"
//     CORES
const vermelho = document.querySelector('.vermelho');
const verde = document.querySelector('.verde');
const azul = document.querySelector('.azul');
const amarelo = document.querySelector('.amarelo');
const branco = document.querySelector('.branco');


//    MAIN
const conteudo = document.querySelector('.conteudo');
const bigText = document.querySelector('.big-text');

vermelho.addEventListener('click', function() {
    conteudo.style.backgroundColor = 'red'
    bigText.style.color = 'black'
})

verde.addEventListener('click', function() {
    conteudo.style.backgroundColor = 'green'
    bigText.style.color = 'red'

})

azul.addEventListener('click', function() {
    conteudo.style.backgroundColor = 'blue'
    bigText.style.color = 'white'
})

amarelo.addEventListener('click', function() {
    conteudo.style.backgroundColor = 'yellow'
    bigText.style.color = 'blue'
})

branco.addEventListener('click', function() {
    conteudo.style.backgroundColor = 'white'
    bigText.style.color = 'black'
})