const btnAlterar = document.getElementById('btn-Alterar')
const imglampada = document.getElementById('lampada')
const baseUrl = "https://23fb4c7f-dd3b-493d-b973-8ae836bfcc3d-00-29miod78t3yaw.kirk.replit.dev/"


btnAlterar.addEventListener('click', function() {


  if (imglampada.src == baseUrl + 'lampada0.png') {
    imglampada.src = "lampada2.png"
  } else {
    imglampada.src = "lampada0.png"
  }





}
)










